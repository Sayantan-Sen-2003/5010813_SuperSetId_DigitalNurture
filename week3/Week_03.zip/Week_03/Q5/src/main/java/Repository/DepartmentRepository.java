package Repository;

import myPackage.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

    // Derived Query Methods
    Department findByName(String name);

    // Custom Query Methods with @Query
    @Query("SELECT d FROM Department d WHERE size(d.employees) > :employeeCount")
    List<Department> findDepartmentsWithMoreThanXEmployees(int employeeCount);
}
